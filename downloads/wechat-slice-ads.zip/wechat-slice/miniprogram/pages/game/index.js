const { CATALOG } = require('../../lib/catalog');
const { SliceGame } = require('../../lib/game');
const { platform } = require('../../lib/platform');
const { sound } = require('../../lib/sound');
const store = require('../../lib/scores');
const { createAds } = require('../../lib/ads');
const adConfig = require('../../config/ads');

const items = CATALOG.map((item, index) => ({ ...item, number: String(index + 1).padStart(2, '0'), image: '/assets/icons/' + item.id + '.png' }));
const categories = ['全部', ...new Set(items.map(item => item.category))];
const durationOptions = [1, 2, 3];
function windowInfo() { return typeof wx.getWindowInfo === 'function' ? wx.getWindowInfo() : wx.getSystemInfoSync(); }
function duration(value) { return durationOptions.includes(value) ? value : 3; }
function dateLabel(value) {
  const date = new Date(value);
  return (date.getMonth() + 1) + '/' + date.getDate() + ' ' + String(date.getHours()).padStart(2, '0') + ':' + String(date.getMinutes()).padStart(2, '0');
}

Page({
  data: {
    items, categories, visibleItems: items, category: '全部', selected: items[0], durations: durationOptions,
    selectedDuration: 3, playerName: '切割新手', soundEnabled: true,
    ready: false, error: '', playing: false, expanded: false, showResult: false, showHelp: false,
    navHeight: 88, statusBarHeight: 44, arenaHeight: 420, boardHeight: 420, modalHeight: 620,
    itemGridWidth: 3468, scrollTop: 0, scrollInto: '',
    pieces: 1, timeLeft: '3.0', progress: 100, phaseLabel: '等待出刀', speedLabel: '待出刀',
    bannerAdUnitId: '', videoAvailable: false, adBusy: false, goldBladeReady: false,
    rankRows: [], rankingIndex: 0, rankingName: '西瓜', best: '—', result: {},
  },
  onLoad() {
    this._alive = true; this._shown = true; this._records = store.loadRecords();
    const info = windowInfo();
    const menu = typeof wx.getMenuButtonBoundingClientRect === 'function' ? wx.getMenuButtonBoundingClientRect() : null;
    const statusBarHeight = info.statusBarHeight || 20;
    const navHeight = menu?.bottom > 0 ? menu.bottom + Math.max(4, menu.top - statusBarHeight) : statusBarHeight + 44;
    this.setData({
      statusBarHeight, navHeight,
      selectedDuration: duration(store.read(store.KEYS.duration, 3)),
      playerName: store.cleanName(store.read(store.KEYS.name, '切割新手')),
      soundEnabled: store.read(store.KEYS.sound, true) !== false,
    });
    this._ads = createAds(wx, adConfig, busy => { if (this._alive) this.setData({ adBusy: busy }); });
    this.setData({ bannerAdUnitId: this._ads.bannerId, videoAvailable: this._ads.available });
    this.updateLayout(info);
    this.refreshBoard();
  },
  onReady() {
    const query = wx.createSelectorQuery().in(this);
    query.select('#arena').boundingClientRect();
    for (const id of ['solid', 'shadow', 'overlay']) query.select('#' + id).fields({ node: true, size: true });
    query.exec(results => {
      if (!this._alive) return;
      try {
        const [bounds, solid, shadow, overlay] = results;
        if (!bounds || !overlay?.node) throw new Error('请更新微信后再试玩');
        const canvas = platform.attach({ solid: solid?.node, shadow: shadow?.node, overlay: overlay.node }, bounds, windowInfo().pixelRatio);
        this._game = new SliceGame(canvas, {
          hoverDuration: this.data.selectedDuration,
          onState: state => this.onGameState(state),
          onStats: stats => this.onGameStats(stats),
          onEnd: result => this.onGameEnd(result),
        });
        this._game.setSound(this.data.soundEnabled);
        platform.setHidden(!this._shown);
        this.setData({ ready: true });
      } catch (error) {
        this._game?.destroy(); this._game = null; platform.detach();
        this.setData({ error: error.message || '游戏画面加载失败，请重新进入' });
      }
    });
  },
  onShow() { this._shown = true; if (this._game) platform.setHidden(false); },
  onHide() { this._shown = false; if (this._game) platform.setHidden(true); sound.dispose(); },
  onUnload() {
    this._alive = false; this._ads?.dispose(); clearTimeout(this._scrollTimer);
    this._game?.destroy(); this._game = null; sound.dispose(); platform.detach();
  },
  onResize(event) {
    const info = windowInfo();
    this.updateLayout({ ...info, ...event.size });
  },
  updateLayout(info) {
    const available = info.windowHeight - this.data.navHeight;
    const landscape = info.windowWidth > info.windowHeight;
    const boardHeight = Math.min(560, Math.max(landscape ? 240 : 320, available - 185));
    const arenaHeight = this.data.expanded ? Math.max(200, available - 12) : boardHeight;
    const safeTop = info.safeArea?.top || info.statusBarHeight || 0;
    const safeBottom = info.safeArea ? Math.max(0, (info.screenHeight || info.windowHeight) - info.safeArea.bottom) : 0;
    const modalHeight = Math.max(200, Math.min(640, info.windowHeight - safeTop - safeBottom - 48));
    this.setData({ boardHeight, arenaHeight, modalHeight }, () => this.measure());
  },
  measure(callback) {
    if (!this._game || !this._alive) { callback?.(); return; }
    wx.createSelectorQuery().in(this).select('#arena').boundingClientRect(bounds => {
      if (!this._alive || !bounds) return;
      platform.resize(bounds, windowInfo().pixelRatio);
      callback?.();
    }).exec();
  },
  onScroll(event) {
    this._scrollTop = event?.detail?.scrollTop || 0;
    clearTimeout(this._scrollTimer);
    this._scrollTimer = setTimeout(() => this.measure(), 60);
  },
  start() {
    if (!this._game || this.data.playing || this.data.showHelp || this.data.adBusy) return;
    // Keep audio activation inside the original tap, before asynchronous measurement.
    sound.unlock(); this.setData({ showResult: false });
    this.measure(() => { if (this._alive && this._shown && this._game && !this.data.playing && !this.data.showHelp && !this.data.adBusy) {
      this._game.goldBlade = this.data.goldBladeReady;
      this._game.start(); this.setData({ goldBladeReady: false });
    } });
  },
  selectItem(event) {
    if (this.data.playing || this.data.adBusy) return;
    const item = items.find(value => value.id === event.currentTarget.dataset.id);
    if (!item || !this._game) return;
    this._game.select(item.id);
    this.setData({ selected: item, rankingIndex: items.indexOf(item), showResult: false });
    this.refreshBoard();
    this.setData({ scrollInto: '', scrollTop: this._scrollTop || 0 }, () => this.setData({ scrollTop: 0 }, () => this.measure()));
    if (this.data.soundEnabled) sound.unlock().then(() => { if (this._alive) sound.cut(item.id, 900, 2); });
  },
  selectCategory(event) {
    if (this.data.playing || this.data.adBusy) return;
    const category = event.currentTarget.dataset.category;
    if (!categories.includes(category)) return;
    const visibleItems = category === '全部' ? items : items.filter(item => item.category === category);
    this.setData({ category, visibleItems, itemGridWidth: Math.ceil(visibleItems.length / 2) * 232 - 12 });
  },
  selectDuration(event) {
    const value = Number(event.currentTarget.dataset.seconds);
    if (this.data.playing || this.data.adBusy || !this._game?.setHoverDuration(value)) return;
    this.setData({ selectedDuration: value, timeLeft: value.toFixed(1) });
    store.write(store.KEYS.duration, value);
  },
  toggleSound() {
    const enabled = !this.data.soundEnabled;
    this.setData({ soundEnabled: enabled });
    this._game?.setSound(enabled); store.write(store.KEYS.sound, enabled);
    if (enabled) sound.unlock();
  },
  toggleExpanded() {
    this.setData({ expanded: !this.data.expanded }, () => this.updateLayout(windowInfo()));
  },
  changeName(event) {
    const name = store.cleanName(event.detail.value);
    this.setData({ playerName: name }); store.write(store.KEYS.name, name);
  },
  changeRanking(event) {
    const index = Number(event.detail.value);
    if (!items[index]) return;
    this.setData({ rankingIndex: index }); this.refreshBoard();
  },
  refreshBoard() {
    const item = items[this.data.rankingIndex] || items[0];
    const list = store.ranked(this._records || [], item.id);
    this.setData({
      rankingName: item.name, best: list[0]?.pieces ?? '—',
      rankRows: list.slice(0, 5).map((record, index) => ({
        id: record.id, rank: index + 1, name: record.name, pieces: record.pieces,
        detail: dateLabel(record.date) + (durationOptions.includes(record.hoverDuration) ? ' · ' + record.hoverDuration + '秒' : ''),
      })),
    });
  },
  onGameState(state) {
    if (!this._alive) return;
    this.setData({ playing: state === 'playing', phaseLabel: state === 'playing' ? '上抛中' : state === 'finished' ? '挑战完成' : '等待出刀' });
  },
  onGameStats(stats) {
    if (!this._alive) return;
    const speed = stats.speed || 0;
    this.setData({
      pieces: stats.pieces, timeLeft: Math.max(0, stats.timeLeft).toFixed(1),
      progress: Math.round(Math.min(1, Math.max(0, stats.timeLeft) / this.data.selectedDuration) * 100),
      phaseLabel: !this.data.playing ? (this.data.showResult ? '挑战完成' : '等待出刀') : stats.phase === 'launch' ? '上抛中' : stats.phase === 'fall' ? '快速坠落' : '空中悬停',
      speedLabel: speed > 2400 ? '极速！' : speed > 1300 ? '飞快' : speed > 550 ? '利落' : speed > 80 ? '轻划' : '待出刀',
    });
  },
  onGameEnd(result) {
    if (!this._alive) return;
    const saved = store.saveResult(this._records, result, this.data.playerName);
    this._records = saved.records;
    const item = items.find(value => value.id === result.itemId) || items[0];
    this.setData({
      showResult: true, rankingIndex: items.indexOf(item),
      result: { ...result, name: item.name, image: item.image, maxSpeed: Math.round(result.maxSpeed),
        eligible: saved.rank !== 0, rank: saved.rank, newRecord: saved.newRecord,
        saved: saved.saved,
        title: saved.rank === 0 ? '下一轮，挥出第一刀' : result.pieces >= 60 ? '切得真痛快！' : '这刀，有点意思。',
      },
    });
    this.refreshBoard();
  },
  async watchRewardedAd() {
    if (!this._alive || !this._shown || this.data.playing || this.data.adBusy || this.data.goldBladeReady) return;
    const completed = await this._ads.show();
    if (!this._alive) return;
    if (completed) this.setData({ goldBladeReady: true });
    wx.showToast?.({ title: completed ? '下一局金色刀光已解锁' : '未完成观看，未领取奖励', icon: 'none' });
  },
  onBannerError() { if (this._alive) this.setData({ bannerAdUnitId: '' }); },
  chooseAnother() { if (this.data.adBusy) return; this._game?.stop(); this.setData({ showResult: false, expanded: false, scrollInto: 'objects-section' }, () => this.updateLayout(windowInfo())); },
  closeResult() { if (this.data.adBusy) return; this._game?.stop(); this.setData({ showResult: false }); },
  openHelp() { if (!this.data.playing) this.setData({ showHelp: true }); },
  closeHelp() { this.setData({ showHelp: false }); },
  swallow() {},
  touchStart(event) { if (!this.data.adBusy && !this.data.showHelp && !this.data.showResult) platform.touch('pointerdown', event); },
  touchMove(event) { if (!this.data.adBusy && !this.data.showHelp && !this.data.showResult) platform.touch('pointermove', event); },
  touchEnd(event) { platform.touch('pointerup', event); },
  touchCancel(event) { platform.touch('pointercancel', event); },
  onShareAppMessage() { return { title: '万物切切乐：刀划到哪片，就把哪片切成两半', path: '/pages/game/index' }; },
});
