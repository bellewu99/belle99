// 微信公众平台 → 流量主 → 广告管理。留空时不显示广告。
module.exports = {
  enabled: true,
  bannerAdUnitId: '',
  rewardedVideoAdUnitId: '',
};
