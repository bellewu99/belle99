const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const sharp = require('sharp');
const root = path.resolve(__dirname, '..');
const { CATALOG } = require('../miniprogram/lib/catalog');
const { iconSVG } = require('../miniprogram/lib/objects');

async function main() {
  const icons = path.join(root, 'miniprogram/assets/icons');
  const audio = path.join(root, 'miniprogram/assets/audio');
  fs.mkdirSync(icons, { recursive: true }); fs.mkdirSync(audio, { recursive: true });
  await Promise.all(CATALOG.map(async item => {
    await sharp(Buffer.from(iconSVG(item.id))).resize(160, 160).png().toFile(path.join(icons, item.id + '.png'));
  }));
  let source = fs.readFileSync(path.join(root, 'miniprogram/lib/sound-procedural.js'), 'utf8');
  source = source.replace(/^const \{.*?\} = require\(.*?\);\s*$/gm, '');
  source = source.replace('let context, master, noiseBuffer;', "let context = {state:'running'}, master, noiseBuffer;");
  function replaceFunction(name, next, replacement) {
    const start = source.indexOf('function ' + name + '(');
    const end = source.indexOf('function ' + next + '(', start);
    if (start < 0 || end < 0) throw new Error('Missing source function: ' + name);
    source = source.slice(0, start) + replacement + '\n\n' + source.slice(end);
  }
  replaceFunction('tone', 'noise', "function tone(frequency,endFrequency,duration,volume,type='sine',delay=0){capture({kind:'tone',frequency,endFrequency,duration,volume,type,delay});}");
  replaceFunction('noise', 'unlock', "function noise(duration,volume,type='lowpass',frequency=1200,endFrequency=frequency,delay=0,q=.7){capture({kind:'noise',frequency,endFrequency,duration,volume,type,delay,q});}");
  replaceFunction('unlock', 'setEnabled', 'function unlock(){return Promise.resolve();}');
  let current = []; let clock = 0;
  const sandbox = { CATALOG, capture: recipe => current.push(recipe), performance: {now: () => clock += 100}, module: {exports: {}}, Math };
  vm.runInNewContext(source, sandbox);
  const sound = sandbox.module.exports.sound;
  const recipes = {};
  for (const item of CATALOG) { current = []; sound.cut(item.id, 1000, 2); recipes[item.id] = current; }
  for (const name of ['start', 'finish', 'tick']) { current = []; sound[name](); recipes[name] = current; }
  if (Object.values(recipes).some(recipe => !recipe.length)) throw new Error('Missing audio recipe');
  fs.writeFileSync(path.join(root, 'tools/audio-recipes.json'), JSON.stringify(recipes, null, 2));
  console.log('30 PNG icons and 33 distinct audio recipes generated.');
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
