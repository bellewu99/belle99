"""Render the original procedural sound recipes into offline PCM fallbacks."""
from pathlib import Path
import json
import math
import random
import struct
import wave

root = Path(__file__).resolve().parent.parent
recipes = json.loads((root / 'tools/audio-recipes.json').read_text())
destination = root / 'miniprogram/assets/audio'
destination.mkdir(parents=True, exist_ok=True)
rate = 22050
for index, (name, voices) in enumerate(recipes.items()):
    rng = random.Random(100 + index)
    length = max(v['delay'] + v['duration'] for v in voices) + .025
    mix = [0.] * math.ceil(length * rate)
    for voice in voices:
        offset = round(voice['delay'] * rate)
        count = max(1, round(voice['duration'] * rate))
        phase = 0.
        previous1 = previous2 = output1 = output2 = 0.
        for i in range(count):
            time = i / rate
            frequency = max(25., voice['frequency']) * (max(25., voice['endFrequency']) / max(25., voice['frequency'])) ** (time / voice['duration'])
            attack = .002 if voice['kind'] == 'noise' else .003
            peak = max(.001, voice['volume'])
            if time < attack:
                envelope = .0001 * (peak / .0001) ** (time / attack)
            else:
                envelope = peak * (.0001 / peak) ** ((time - attack) / max(.001, voice['duration'] - attack))
            if voice['kind'] == 'tone':
                phase += frequency / rate
                position = phase % 1.
                kind = voice['type']
                value = math.sin(2 * math.pi * phase) if kind == 'sine' else (1. if position < .5 else -1.) if kind == 'square' else 2 * position - 1 if kind == 'sawtooth' else 1 - 4 * abs(position - .5)
            else:
                angle = 2 * math.pi * min(rate * .45, frequency) / rate
                cosine, sine = math.cos(angle), math.sin(angle)
                alpha = sine / (2 * max(.1, voice.get('q', .7)))
                denominator = 1 + alpha
                if voice['type'] == 'highpass':
                    b0, b1, b2 = (1 + cosine) / 2, -(1 + cosine), (1 + cosine) / 2
                elif voice['type'] == 'bandpass':
                    b0, b1, b2 = alpha, 0, -alpha
                else:
                    b0, b1, b2 = (1 - cosine) / 2, 1 - cosine, (1 - cosine) / 2
                sample = rng.uniform(-1, 1)
                value = (b0 * sample + b1 * previous1 + b2 * previous2 + 2 * cosine * output1 - (1 - alpha) * output2) / denominator
                previous2, previous1 = previous1, sample
                output2, output1 = output1, value
            mix[offset + i] += value * envelope
    peak = max(abs(value) for value in mix) or 1
    gain = min(1., .88 / peak)
    samples = b''.join(struct.pack('<h', round(max(-1., min(1., value * gain)) * 32767)) for value in mix)
    with wave.open(str(destination / (name + '.wav')), 'wb') as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(rate)
        output.writeframes(samples)
print(f'{len(recipes)} local audio clips rendered; no audio domain or network required.')
