const assert = require('node:assert/strict');
const { createAds } = require('../miniprogram/lib/ads');
const config = { enabled: true, bannerAdUnitId: 'adunit-banner1', rewardedVideoAdUnitId: 'adunit-video1' };
function fixture(show = async () => {}) {
  const handlers = {}, counts = { show: 0, load: 0, destroy: 0 }, busy = [];
  const video = {
    onClose: fn => handlers.close = fn, onError: fn => handlers.error = fn,
    offClose: fn => { assert.equal(fn, handlers.close); delete handlers.close; },
    offError: fn => { assert.equal(fn, handlers.error); delete handlers.error; },
    show: () => { counts.show++; return show(counts.show); },
    load: async () => { counts.load++; }, destroy: () => counts.destroy++,
  };
  const ads = createAds({ createRewardedVideoAd: () => video }, config, state => busy.push(state));
  return { ads, handlers, counts, busy, video };
}
(async () => {
  let calls = 0;
  const empty = createAds({ createRewardedVideoAd() { calls++; } }, { enabled: true });
  assert.equal(empty.bannerId, ''); assert.equal(empty.available, false); assert.equal(await empty.show(), false); assert.equal(calls, 0);
  assert.equal(createAds({}, config).available, false);
  assert.equal(createAds({}, { ...config, enabled: false }).bannerId, '');
  for (const event of [{ isEnded: true }, { isEnded: false }, undefined]) {
    const f = fixture(), result = f.ads.show();
    assert.equal(await f.ads.show(), false); assert.equal(f.counts.show, 1);
    f.handlers.close(event); f.handlers.close({ isEnded: true });
    assert.equal(await result, event?.isEnded === true); assert.deepEqual(f.busy, [true, false]);
    f.ads.dispose(); assert.equal(f.counts.destroy, 1); assert.equal(f.handlers.close, undefined);
  }
  const retry = fixture(async n => { if (n === 1) throw Error('not loaded'); });
  const retried = retry.ads.show(); await new Promise(setImmediate);
  assert.equal(retry.counts.show, 2); assert.equal(retry.counts.load, 1);
  retry.handlers.close({ isEnded: true }); assert.equal(await retried, true); retry.ads.dispose();
  const failed = fixture(async () => { throw Error('no inventory'); });
  assert.equal(await failed.ads.show(), false); assert.equal(failed.counts.show, 2); failed.ads.dispose();
  let release; const stale = fixture(() => new Promise((_, reject) => release = reject));
  const cancelled = stale.ads.show(); stale.ads.dispose(); release(Error('late')); await new Promise(setImmediate);
  assert.equal(await cancelled, false); assert.equal(stale.counts.load, 0); assert.equal(await stale.ads.show(), false);
  const errored = fixture(), pending = errored.ads.show(); errored.handlers.error({ errCode: 1004 });
  assert.equal(await pending, false); errored.ads.dispose();
  console.log('PASS ads: blank configuration, unsupported API, completed/early/unknown close, duplicate taps, retry, failure, disposal and stale promises');
})().catch(error => { console.error(error); process.exitCode = 1; });
