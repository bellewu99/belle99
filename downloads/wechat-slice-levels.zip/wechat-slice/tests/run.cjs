// Native API contract tests, not a substitute for WeChat Developer Tools or a phone.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
let clock = 1000, frames = new Map(), frameId = 0, draws = 0, webglEnabled = true, storageFailure = false;
const memory = new Map();
const players = [];
let bounds = {left: 12, top: 176, width: 366, height: 440};
let info = {windowWidth: 390, windowHeight: 844, statusBarHeight: 44, pixelRatio: 3};
const context2d = () => new Proxy({}, {
  get(target, key) {
    if (key in target) return target[key];
    if (key === 'createLinearGradient' || key === 'createRadialGradient') return () => ({addColorStop() {}});
    if (key === 'measureText') return () => ({width: 30});
    if (key === 'drawImage') return canvas => assert.ok(canvas instanceof MockCanvas, 'Native drawImage must receive the actual offscreen Canvas node');
    return () => {};
  },
  set(target, key, value) {target[key] = value; return true;},
});
const contextGL = () => new Proxy({}, {
  get(target, key) {
    if (key in target) return target[key];
    if (/^[A-Z_]+$/.test(key)) {target[key] = Object.keys(target).length + 1; return target[key];}
    if (key === 'isContextLost') return () => false;
    if (key === 'getShaderParameter' || key === 'getProgramParameter') return () => true;
    if (key === 'getAttribLocation') return () => 0;
    if (key.startsWith('create') || key === 'getUniformLocation') return () => ({});
    if (key === 'drawArrays') return () => draws++;
    return () => {};
  },
});
class MockCanvas {
  constructor(type) {this.type = type; this.width = 0; this.height = 0; this.context = type === 'webgl' ? contextGL() : context2d();}
  getContext(type) {return type === this.type && (type !== 'webgl' || webglEnabled) ? this.context : null;}
  requestAnimationFrame(fn) {const id = ++frameId; frames.set(id, fn); return id;}
  cancelAnimationFrame(id) {frames.delete(id);}
}
function canvasNodes() {return {solid: new MockCanvas('webgl'), shadow: new MockCanvas('2d'), overlay: new MockCanvas('2d')};}
function selectorQuery() {
  const requests = [];
  return {
    in() {return this;},
    select(id) {this.id = id; return this;},
    boundingClientRect(callback) {requests.push({kind: 'rect', id: this.id, callback}); return this;},
    fields() {requests.push({kind: 'node', id: this.id}); return this;},
    exec(callback) {
      const nodes = canvasNodes();
      const results = requests.map(request => request.kind === 'rect' ? {...bounds} : {node: nodes[request.id.slice(1)], width: bounds.width, height: bounds.height});
      requests.forEach((request, index) => request.callback?.(results[index]));
      callback?.(results);
    },
  };
}
global.wx = {
  getPerformance: () => ({now: () => clock}),
  createOffscreenCanvas: ({type, width, height}) => {const canvas = new MockCanvas(type); canvas.width = width; canvas.height = height; return canvas;},
  getStorageSync: key => memory.get(key) ?? '',
  setStorageSync: (key, value) => {if (storageFailure) throw new Error('storage unavailable'); memory.set(key, value);},
  createInnerAudioContext() {
    const player = {plays: 0, stops: 0, destroyed: false, onError() {}, play() {this.plays++;}, stop() {this.stops++;}, destroy() {this.destroyed = true;}};
    players.push(player); return player;
  },
  getWindowInfo: () => ({...info}), getMenuButtonBoundingClientRect: () => ({top: 50, bottom: 82}),
  createSelectorQuery: selectorQuery,
};
const {CATALOG} = require('../miniprogram/lib/catalog');
const {platform, performance} = require('../miniprogram/lib/platform');
const {SliceGame, polygonArea} = require('../miniprogram/lib/game');
const {sound} = require('../miniprogram/lib/sound');
const score = require('../miniprogram/lib/scores');
const reports = [];
async function test(name, fn) {
  try {await fn(); reports.push({name, pass: true}); console.log('PASS ' + name);}
  catch (error) {reports.push({name, pass: false, error: error.stack}); console.error('FAIL ' + name + '\n' + error.stack);}
}
function engine(duration = 3, callbacks = {}) {
  const canvas = platform.attach(canvasNodes(), bounds, info.pixelRatio);
  return new SliceGame(canvas, {hoverDuration: duration, ...callbacks});
}
function frame(ms = 16) {
  clock += ms; const pending = [...frames.values()]; frames.clear();
  for (const callback of pending) callback(123); // Native RAF timestamp is intentionally a different clock.
}
function touch(type, x, y, identifier = 7, local = false) {
  clock += 20;
  const position = local ? {x, y, identifier} : {clientX: bounds.left + x, clientY: bounds.top + y, identifier};
  platform.touch(type, {changedTouches: [position]});
}
function freshPage() {
  let definition;
  global.Page = value => {definition = value;};
  const name = require.resolve('../miniprogram/pages/game/index'); delete require.cache[name]; require(name);
  const page = {...definition, data: structuredClone(definition.data)};
  page.setData = function(data, callback) {Object.assign(this.data, data); callback?.();};
  page.onLoad(); page.onReady(); return page;
}
async function main() {
  await test('project, page bindings and offline assets are complete', () => {
    const config = JSON.parse(fs.readFileSync(path.join(root, 'project.config.json')));
    assert.equal(config.compileType, 'miniprogram'); assert.equal(config.miniprogramRoot, 'miniprogram/');
    const appConfig = JSON.parse(fs.readFileSync(path.join(root, 'miniprogram/app.json')));
    assert.equal(appConfig.window.pageOrientation, 'auto');
    assert.equal(CATALOG.length, 30); assert.equal(new Set(CATALOG.map(item => item.id)).size, 30);
    assert.equal(new Set(CATALOG.map(item => item.category)).size, 6);
    const hashes = new Set();
    for (const item of CATALOG) {
      const image = fs.readFileSync(path.join(root, 'miniprogram/assets/icons', item.id + '.png'));
      assert.equal(image.subarray(1, 4).toString(), 'PNG');
      const audio = fs.readFileSync(path.join(root, 'miniprogram/assets/audio', item.id + '.wav'));
      assert.equal(audio.subarray(0, 4).toString(), 'RIFF');
      assert.ok(audio.length > 1000); hashes.add(crypto.createHash('sha256').update(audio).digest('hex'));
    }
    assert.equal(hashes.size, 30);
    for (const name of ['start', 'tick', 'finish']) assert.ok(fs.existsSync(path.join(root, 'miniprogram/assets/audio', name + '.wav')));
    const page = freshPage();
    const wxml = fs.readFileSync(path.join(root, 'miniprogram/pages/game/index.wxml'), 'utf8');
    assert.ok(!wxml.includes('web-view'));
    for (const match of wxml.matchAll(/(?:bind|catch)(?:tap|touchstart|touchmove|touchend|touchcancel|blur|change|scroll)="(\w+)"/g)) assert.equal(typeof page[match[1]], 'function', match[1]);
    page.onUnload(); assert.equal(frames.size, 0);
    for (const file of walk(path.join(root, 'miniprogram')).filter(file => file.endsWith('.js'))) new Function(fs.readFileSync(file, 'utf8'));
  });
  await test('30 materials × 1/2/3-second rounds use native nodes and finish exactly once', () => {
    let total = 0;
    for (const item of CATALOG) for (const duration of [1, 2, 3]) {
      const results = []; const game = engine(duration, {onEnd: result => results.push(result)});
      game.select(item.id); game.start(); frame();
      assert.ok(game.visual, 'WebGL renderer should be attached to the native canvas');
      while (game.elapsed + .050001 < game.roundDuration) frame(50);
      assert.equal(results.length, 0);
      frame(60); frame(50);
      assert.equal(results.length, 1); assert.equal(results[0].itemId, item.id); assert.equal(results[0].hoverDuration, duration);
      assert.ok(Math.abs(results[0].duration - (.8 + duration + .35)) < 1e-9); game.destroy(); platform.detach(); total++;
    }
    assert.equal(total, 90); assert.ok(draws > 90); assert.equal(frames.size, 0);
  });
  await test('one continuous native touch halves the touched fragment, reverses without lifting, and conserves area', () => {
    const game = engine(); game.start(); frame(); game._update(.05, clock, .81);
    const center = game.fragments[0]; const y = center.y;
    touch('pointerdown', 10, y); touch('pointermove', bounds.width - 10, y);
    assert.equal(game.fragments.length, 2);
    touch('pointermove', 10, y + 35);
    assert.ok(game.fragments.length >= 3); assert.ok(game.cuts >= 2);
    const sum = game.fragments.reduce((value, fragment) => value + polygonArea(fragment.polygon), 0);
    assert.ok(Math.abs(sum - game.initialArea) < game.initialArea * 1e-8);
    touch('pointermove', 200, y, 99); assert.equal(game.pointer.id, 7);
    platform.touch('pointercancel', {changedTouches: [], touches: []}); assert.equal(game.pointer, null);
    game.destroy(); platform.detach();
  });
  await test('local canvas touch coordinates and viewport coordinates produce the same split', () => {
    for (const local of [false, true]) {
      const game = engine(); game.start(); game._update(.05, clock, .81);
      const y = game.fragments[0].y;
      touch('pointerdown', 10, y, 7, local); touch('pointermove', bounds.width - 10, y, 7, local);
      assert.equal(game.fragments.length, 2); game.destroy(); platform.detach();
    }
  });
  await test('resize rebases the active finger instead of slicing across orientation coordinates', () => {
    const old = {...bounds}; const game = engine(); game.start(); game._update(.05, clock, .81);
    touch('pointerdown', 20, 100); assert.equal(game.pointer.id, 7);
    bounds = {left: 12, top: 90, width: 720, height: 270}; platform.resize(bounds, 2);
    assert.equal(game.pointer.point, null);
    const count = game.fragments.length; touch('pointermove', 50, 100);
    assert.equal(game.fragments.length, count); assert.equal(game.pointer.id, 7);
    game.destroy(); platform.detach(); bounds = old;
  });
  await test('native lifecycle pauses round time, drops stale touches, and unload cancels RAF', () => {
    const game = engine(); game.start(); frame(); frame(150); const elapsed = game.elapsed;
    touch('pointerdown', 20, 100); platform.setHidden(true); assert.equal(game.pointer, null);
    frame(3000); assert.equal(game.elapsed, elapsed);
    platform.setHidden(false); frame(3000); assert.equal(game.elapsed, elapsed);
    frame(50); assert.ok(game.elapsed > elapsed && game.elapsed < elapsed + .1);
    game.destroy(); platform.detach(); assert.equal(frames.size, 0);
  });
  await test('unsupported WebGL keeps native 2D gameplay and scoring available', () => {
    webglEnabled = false;
    const game = engine(); assert.equal(game.visual, null); game.start(); frame(); game._update(.05, clock, .81);
    const y = game.fragments[0].y; touch('pointerdown', 10, y); touch('pointermove', bounds.width - 10, y);
    frame(); assert.equal(game.fragments.length, 2);
    game.destroy(); platform.detach(); webglEnabled = true;
    const canvas = platform.attach({overlay: new MockCanvas('2d')}, bounds, 2);
    const missingNodeGame = new SliceGame(canvas);
    assert.equal(missingNodeGame.visual, null); missingNodeGame.start(); frame();
    missingNodeGame.destroy(); platform.detach();
  });
  await test('30 independent local rankings cap history, persist duration, and ignore unsliced rounds', () => {
    memory.clear(); let records = [];
    const result = {itemId: 'watermelon', pieces: 7, cuts: 3, maxSpeed: 1300, hoverDuration: 2, duration: 3.15};
    const first = score.saveResult(records, result, '  小刀  ', 100); records = first.records;
    assert.equal(first.rank, 1); assert.equal(first.saved, true); assert.equal(records[0].name, '小刀');
    records = score.saveResult(records, {...result, itemId: 'wood', pieces: 17}, '木头', 101).records;
    for (let i = 0; i < 110; i++) records = score.saveResult(records, {...result, pieces: 8 + i}, '小刀', 200 + i).records;
    assert.equal(score.ranked(records, 'watermelon').length, 100); assert.equal(score.ranked(records, 'wood').length, 1);
    assert.equal(score.ranked(records, 'watermelon')[0].pieces, 117);
    assert.equal(score.ranked(score.loadRecords(), 'watermelon')[0].hoverDuration, 2);
    assert.equal(score.saveResult(records, {...result, cuts: 0, pieces: 1}, '无刀').records.length, records.length);
    storageFailure = true; const failure = score.saveResult(records, {...result, pieces: 500}, '小刀');
    assert.equal(failure.saved, false); assert.equal(failure.rank, 1); storageFailure = false;
    memory.clear();
  });
  await test('page duration lock, category picker, material selection, and result/restart work together', () => {
    const page = freshPage(); assert.equal(page.data.ready, true); assert.equal(page.data.items.length, 30);
    page.selectDuration({currentTarget: {dataset: {seconds: 1}}}); assert.equal(page._game.hoverDuration, 1);
    page.selectCategory({currentTarget: {dataset: {category: '文具'}}}); assert.equal(page.data.visibleItems.length, 5);
    assert.equal(page.data.itemGridWidth, 684);
    page.selectItem({currentTarget: {dataset: {id: 'pencil'}}}); assert.equal(page._game.itemId, 'pencil');
    page.start(); assert.equal(page.data.playing, true);
    page.selectDuration({currentTarget: {dataset: {seconds: 3}}}); assert.equal(page._game.hoverDuration, 1);
    frame(); while (page._game.state === 'playing') frame(100);
    assert.equal(page.data.showResult, true); assert.equal(page.data.result.name, '铅笔'); assert.equal(page.data.result.hoverDuration, 1);
    page.start(); assert.equal(page.data.showResult, false); assert.equal(page._game.state, 'playing');
    page.onHide(); assert.equal(page._game.pointer, null); page.onShow();
    page.toggleExpanded(); assert.equal(page.data.expanded, true); assert.ok(page.data.arenaHeight > page.data.boardHeight);
    page.chooseAnother(); assert.equal(page.data.scrollInto, 'objects-section');
    info = {...info, windowWidth: 844, windowHeight: 390}; page.onResize({size: {windowWidth: 844, windowHeight: 390}});
    assert.ok(page.data.modalHeight < 390); assert.ok(page.data.modalHeight >= 200);
    info = {...info, windowWidth: 390, windowHeight: 844};
    page.onUnload(); assert.equal(frames.size, 0);
  });
  await test('90 challenge definitions, star boundaries, unlocking and progress validation', () => {
    const c = require('../miniprogram/lib/levels');
    for (const d of c.DIFFICULTIES) {
      let progress = c.cleanProgress({});
      assert.equal(c.levels(d.id, progress).length, 30);
      assert.equal(c.complete(progress, d.id, 2, 1000).passed, false);
      for (let n = 1; n <= 30; n++) {
        const level = c.levels(d.id, progress)[n - 1];
        assert.equal(level.unlocked, true); assert.equal(level.seconds, d.seconds);
        assert.equal(c.complete(progress, d.id, n, level.target - 1).passed, false);
        const one = c.complete(progress, d.id, n, level.target); assert.equal(one.stars, 1);
        const two = c.complete(progress, d.id, n, Math.ceil(level.target * 1.4)); assert.equal(two.stars, 2);
        const three = c.complete(progress, d.id, n, Math.ceil(level.target * 1.8)); assert.equal(three.stars, 3);
        progress = c.complete(three.progress, d.id, n, level.target).progress;
        assert.equal(progress[d.id][n - 1], 3);
      }
    }
    assert.equal(c.cleanProgress({easy: [-1, Infinity, '3', 4]}).easy.some(Boolean), false);
  });
  await test('challenge page locks rules, scales targets, saves progress and isolates free rankings', () => {
    const c = require('../miniprogram/lib/levels'); memory.delete(c.KEY);
    const page = freshPage(), records = page._records.length;
    const event = dataset => ({currentTarget: {dataset}});
    page.selectMode(event({mode: 'challenge'}));
    const big = page._game.objectRadius;
    page.selectLevel(event({number: 2})); assert.equal(page.data.levelNumber, 1);
    page.selectDifficulty(event({id: 'hard'})); assert.equal(page._game.hoverDuration, 1);
    assert.ok(page._game.objectRadius < big);
    page.selectDuration(event({seconds: 3})); assert.equal(page._game.hoverDuration, 1);
    page.selectItem(event({id: 'pencil'})); assert.equal(page._game.itemId, CATALOG[0].id);
    page.start(); page.selectMode(event({mode: 'free'})); assert.equal(page.data.mode, 'challenge');
    frame(); while (page._game.state === 'playing') frame(100);
    assert.equal(page.data.result.passed, false); assert.equal(page.data.levelList[1].unlocked, false);
    page.start(); const round = {...page._roundChallenge}; page._game.stop();
    page.onGameEnd({itemId: round.itemId, pieces: round.target, cuts: round.target - 1, maxSpeed: 500, hoverDuration: 1});
    assert.equal(page.data.result.passed, true); assert.equal(page._records.length, records);
    assert.equal(page.data.levelList[1].unlocked, true); assert.equal(memory.get(c.KEY).hard[0], 1);
    page.nextLevel(); assert.equal(page.data.levelNumber, 2); assert.equal(page.data.showResult, false);
    page.selectMode(event({mode: 'free'})); assert.equal(page._game.challengeScale, 1);
    assert.equal(page._game.hoverDuration, score.read(score.KEYS.duration, 3));
    page.onUnload(); const restored = freshPage();
    restored.selectMode(event({mode: 'challenge'})); restored.selectDifficulty(event({id: 'hard'}));
    assert.equal(restored.data.levelList[1].unlocked, true);
    storageFailure = true; restored.start(); restored._game.stop();
    restored.onGameEnd({itemId: CATALOG[0].id, pieces: 20, cuts: 19, maxSpeed: 500, hoverDuration: 1});
    assert.equal(restored.data.result.saved, false); storageFailure = false; restored.onUnload();
  });
  await test('WAV fallback is bounded, debounced, mute-aware, and releases native audio on hide', async () => {
    sound.dispose(); sound.setEnabled(true); await sound.unlock();
    const before = players.length;
    for (let i = 0; i < 50; i++) {clock += 50; sound.cut(CATALOG[i % 30].id, 2000, 2);}
    assert.equal(players.length - before, 8);
    const batch = players.slice(before); const played = batch.reduce((total, player) => total + player.plays, 0);
    assert.equal(played, 50); sound.cut('ice', 1000, 2); assert.equal(batch.reduce((total, player) => total + player.plays, 0), played);
    sound.setEnabled(false); clock += 60; sound.cut('wood', 1000, 2); assert.equal(batch.reduce((total, player) => total + player.plays, 0), played);
    sound.dispose(); assert.ok(batch.every(player => player.destroyed)); sound.setEnabled(true);
    clock += 60; await sound.unlock(); sound.start(); assert.equal(players.length - before, 16); sound.dispose();
  });
  await test('incomplete native Web Audio releases its context and falls back without recreating on every swipe', async () => {
    let created = 0, destroyed = 0;
    wx.createWebAudioContext = () => {created++; return {destroy() {destroyed++;}};};
    sound.dispose(); sound.setEnabled(true);
    await sound.unlock(); await sound.unlock(); await sound.unlock();
    assert.equal(created, 1); assert.equal(destroyed, 1);
    const before = players.length; clock += 60; sound.cut('marble', 1000, 2);
    assert.equal(players.length - before, 8); assert.ok(players.at(-8).src.endsWith('/marble.wav'));
    sound.dispose(); delete wx.createWebAudioContext;
  });
  fs.writeFileSync(path.join(root, 'tests/results.json'), JSON.stringify({kind: 'mocked-native-api-contract', trueDevice: false, tests: reports}, null, 2) + '\n');
  console.log(`${reports.filter(report => report.pass).length}/${reports.length} checks passed; no real-device claim.`);
  if (reports.some(report => !report.pass)) process.exitCode = 1;
}
function walk(directory) {return fs.readdirSync(directory, {withFileTypes: true}).flatMap(entry => entry.isDirectory() ? walk(path.join(directory, entry.name)) : [path.join(directory, entry.name)]);}
main().catch(error => {console.error(error); process.exitCode = 1;});
